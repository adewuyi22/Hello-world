<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        $db_host = 'localhost';
        $db_user = 'root';
        $db_pass = '';
        
        $db_name = 'chat';
        
        if ($connection = mysqli_connect($db_host, $db_user, $db_pass)) {
            echo "Connected to database server <br />";
            
            if ($database = @mysqli_select_db($db_name, $connection)) {
                echo 'Database has been selected... <br />';
            }else {
                echo "Database does not exist <br>";
            }
            
        }
        else {
            echo 'unable to connect to MYSQL SERVER... <br />';
        }
?>
    </body>
</html>
