<?php

require ('includes/database/connect.db.php');
require ('includes/functions/chat.func.php');


?>

