<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>Chat online</title>
    </head>
    <body>
        <?php
       require ('includes/core.inc.php');
       
       if (isset($_POST['send'])) {
           if (send_msg($_POST['sender']&& $_POST['message']))
           {
               echo "Message sent...";
           }
           else {
               echo "Message fail to sends";
           }
       }
      
        ?>
        
        <div id="messages"> 
        <?php
            $messages = get_msg();
            foreach ($messages as $message) {
                echo '<b>'.$message['sender'].'Sent </b><br />';
                echo $message['message'].'<br /><br />';
            }
        ?>
        
        </div>
        
        <br>
        <form action="index.php" method="post"> 
            <lable> Name: <input type="text" name="sender" placeholder="Enter your name" </lable>
           <lable> Enter Message: <input type="text" name="message" placeholder="your message" </lable><br>
            <input type="submit" value="Send">
            
            
        </form>
        
    </body>
</html>
